plugins { id("com.android.application") }

android {
    namespace = "com.example.nikesport01"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.nikesport01"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
