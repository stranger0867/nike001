Sport 01 — Galaxy Watch7 表盘项目

这是一个 Wear OS Watch Face Format (WFF) 项目源码，不是已经编译好的 APK。
设计方向：黑底、白色大号数字时间、荧光绿运动点缀、日期、实时步数。

构建环境：
- Android Studio（建议较新稳定版）
- Android SDK Platform 35
- JDK 17

构建步骤：
1. 在电脑上安装 Android Studio。
2. 解压本项目，在 Android Studio 中打开 NikeSport01 文件夹。
3. 等待 Gradle Sync 完成；如提示缺少 SDK 35，按提示安装。
4. 选择 watchface 模块，执行 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常生成在 watchface/build/outputs/apk/debug/ 目录。
6. 将 APK 安装到已开启开发者选项和无线调试的 Galaxy Watch7，或使用 ADB 安装。

注意：
- 当前运行环境没有 Android SDK / Gradle，因此这里不能声称已成功编译或通过真机验证。
- 首版使用 WFF 1，面向 Wear OS 4 及以上；Watch7 可运行 WFF。
- 预览图只是设计示意，实际字体大小、布局和数据源需在模拟器/手表上验证后微调。
- 图形采用原创运动风元素，不代表 Nike 官方产品或授权表盘。
